/*      	 "awesome_shell" presented by : 
	srikar chundury - 01fb15ecs306  , 
	sumanth s rao  - 01fb15ecs314 , 
	varun venkatesh - 01fb15ecs331
*/
#include<unistd.h>
#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sysexits.h>

#include "fcntl.h"

#define C_MAX 1024
#define ARG_MAX 5
#define KNRM  "\x1B[0m"
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KMAG  "\x1B[35m"
#define KCYN  "\x1B[36m"
#define KWHT  "\x1B[37m"

FILE *hist;
int saved_stdout,saved_stdin;
int in, out;
int ou=0,inter=0;

char *pre_process(char *inp){
	char *new = (char *)malloc(sizeof(char)*(strlen(inp)+10));
	int k=0,i;
	for(i=0;i<strlen(inp);i++){
		if(inp[i]=='|' || inp[i]=='<' || inp[i]=='>'){
			new[k++]=' ';new[k++]=inp[i];new[k++]=' ';
		}
		else{
			new[k++]=inp[i];
		}
	}
	return new;
}
char **com_n_args(char *inp){
	char **res;
	res = (char **)malloc(sizeof(char *)*ARG_MAX);
	int k=0;
	char *token = strtok(inp," ");
	while(token != NULL){
		res[k]=(char *)malloc(sizeof(char)*10);
		strcpy(res[k++],token);
		token = strtok(NULL," ");
	}
	res[k] = (char *)malloc(sizeof(char)*10);
	res[k] = NULL;
	return res;
}
char *do_pip_stuff(char **inp){
	int i=0;
	char *new = (char *)malloc(sizeof(char)*(ARG_MAX*10));
	int k=0;
	do{
		if( strcmp(inp[i],">")==0 ){
			char dest[100];
			strcpy(dest,inp[i+1]);
			out = open(dest, O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
			saved_stdout = dup(1);
			dup2(out, 1);
			close(out);
			ou = 1;
			i++;
		}
		else if( strcmp(inp[i],"<")==0 ){
			char src[100];
			strcpy(src,inp[i+1]);
			printf("\n---src = %s---\n",src);
			in = open(src, O_RDONLY);
			saved_stdout = dup(0);
			dup2(in, 0);
			close(in);
			inter = 1;
			i++;
		}
		else if( strcmp(inp[i],"|")==0 ){
			//first seperate into commands , then execute
		}
		else{
			int j;
			for(j=0;j<strlen(inp[i]);j++){
				new[k++] = inp[i][j];
			}
			new[k++]=' ';
		}
		i++;
	}while( inp[i] != NULL );
	new[k]='\0';
	return new;
}
void do_func(){
	int status;
	pid_t pid;
	char *input;
	input = (char *)malloc(sizeof(char)*C_MAX);
	gets(input);
	if(strlen(input)==0)return;
	char *p_input = pre_process(input);
	char **list = com_n_args(p_input);
	p_input = do_pip_stuff(list);
	list = com_n_args(p_input);
	if(strcmp(*list,"hist")==0){
		char line[100];
		FILE *new = fopen("shell_history.txt","r");
		while( fgets(line,100,new) !=NULL ){
			printf("%s",line);
		}
		hist = fopen("shell_history.txt", "a");
		fprintf(hist,"hist\n");
		fclose(hist);
		fclose(new);
	}
	if(1){
		char line[100];
		FILE *new = fopen("alias.txt","r");
		while( fgets(line,100,new) !=NULL ){
			int z=0,q=0,r=0;
			char alias[10];
			char actual[100];
			while(line[z]!=':'){
				alias[q++]=line[z];
				z++;
			}
			alias[q]='\0';
			z++;
			if( strcmp(*list,alias)==0 ){
				while(line[z]!='\0'){
					actual[r++]=line[z];
					z++;
				}
				actual[r-1]='\0';
				strcpy(input,actual);
				p_input = pre_process(input);
				list = com_n_args(p_input);
			}
		}
		fclose(new);
	}
	if(strcmp(*list,"cd")==0){
		chdir(list[1]);
		hist = fopen("shell_history.txt", "a");
		fprintf(hist,"%s\n",input);
		fclose(hist);
	}
	else{
		hist = fopen("shell_history.txt", "a");
		fprintf(hist,"%s\n",input);
		fclose(hist);
		if((pid=fork()) == -1){
			fprintf(stderr,"awe_shell : can't fork : %s\n",strerror(errno));
		}
		else if(pid==0){
			execvp(*list,list);
			fprintf(stderr,"awe_shell : can't exec : %s\n",strerror(errno));
			exit(EX_DATAERR);			 
		}
		if( (pid=waitpid(pid,&status,0)) < 0 ){
			fprintf(stderr,"awe_shell : waitpid error : %s\n",strerror(errno));
		}
	}
	
}
void main(){
	printf("\tWELCOME TO 'AWESOME' SHELL [PHASE - 2]....\n\n\t\tSrikar Chundury - 01FB15ECS306\n\t\tSumanth S Rao - 01FB15ECS314\n\t\tVarun V-01FB15ECS331\n\n");
	printf(KGRN "To make alias , please add lines to alias.txt ,");printf(KCYN " syntax : <alias_nam>:<actual_cmd>\t\n");
	printf(KGRN "----------check out the hist command----------\n");
	while(1){
		char* path = (char *)malloc(sizeof(char)*100);
		getcwd(path,100);
		printf(KRED "awesome_shell_:");
		printf(KBLU "%s",path);
		printf(KRED "$");
		do_func();
		if(ou){
			dup2(saved_stdout, 1);
			close(saved_stdout);
		}
		if(inter){
			dup2(saved_stdin, 0);
			close(saved_stdin);
		}
	}
}
